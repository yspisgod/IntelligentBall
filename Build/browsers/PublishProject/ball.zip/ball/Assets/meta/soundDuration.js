soundDurationMap = {
  "Assets/audio/music/wrong.mp3.bin": 0.22483333333333333,
  "Assets/audio/music/win.mp3.bin": 1.131875
};

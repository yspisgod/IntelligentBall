assetCountMap = {
  "Assets/scene/Main.bin": 2,
  "Temp/scene_editor.bin": 2
};

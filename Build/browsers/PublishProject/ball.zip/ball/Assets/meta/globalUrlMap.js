urlMapConfig = {
  "914133c4-4c4b-425c-9157-36845b35bdac": "Assets/audio/music/win.mp3.bin",
  "cdb2666f-d990-4a02-866e-b288d47c1469": "Assets/audio/music/wrong.mp3.bin",
  "ac3ee5ee-bc3b-406c-9ff3-79ae9128e02b": "Assets/scene/Main.bin",
  "4696cae9-5b00-42f1-813a-adf6851fb58e": "Temp/scene_editor.bin"
};
